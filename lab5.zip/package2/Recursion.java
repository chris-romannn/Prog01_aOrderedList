package package2;

import java.util.ArrayList;

public class Recursion {
    public static void main(String[] args){
        ArrayList<Integer> sortedList = new ArrayList<>();
        sortedList.add(5);
        sortedList.add(10);
        sortedList.add(20);
        sortedList.add(30);
        sortedList.add(40);
        int target = 20;
        int result = recursiveBinarySearch(sortedList, target);
        if (result != -1) {
            System.out.println("Element " + target + " found at index " + result);
        } else {
            System.out.println("Element " + target + " not found in the list");
        } }







    public static int recursiveBinarySearch(ArrayList<Integer> a, int target){
        int min = 0;
        int max = a.size() - 1;
        int retVal = -1;
        while (min <= max) {
            int mid = (min + max) / 2;
            if (target > a.get(mid))
                min=mid+1;// target in 2nd half min = mid + 1;
    else if (target < a.get(mid))
        max=mid-1;// target in 1st half max = mid - 1;
    else
        retVal=mid;
        }
        return retVal; }

}

